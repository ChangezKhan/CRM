<?php include(erLhcoreClassDesign::designtpl('lhsugarcrm/index_title.tpl.php'));?>
<ul>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('sugarcrm/configuration')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('sugarcrm/module', 'Configuration')?></a></li>
</ul>