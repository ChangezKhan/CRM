<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt">
</TS>