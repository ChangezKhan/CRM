Author: Remigijus Kiminas
Version: 1.0

This module brings tight integration SugarCRM with Live Helper Chat

Requirements:
a. PHP Soap module
b. Live Helper Chat since 2.30v 

Install:
 * Put sugarcrm on your server extensions folder.
 * Enable extension in settings.ini.php file.
'extensions' => 
      array (
        'sugarcrm',
      ),
 * Clean cache from back office.
 * From top menu go to Extra Modules => SugarCRM
 * Just configure and use

In chat window will be new tab SugarCRM there wou can create/update existing Chat Lead