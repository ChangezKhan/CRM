<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$errors = array();
if (isset($this->installdefs['copy']))
{
    $query = "SELECT manifest FROM upgrade_history WHERE status = 'installed' AND (name LIKE 'Bug%' OR name LIKE 'HotFix%')";
    $result = $GLOBALS['db']->query($query, false);

    $installedCopy = array();
    while($row = $GLOBALS['db']->fetchByAssoc($result) )
    {
        $installedManifest = array();

        try
        {
            $installedManifest = unserialize(base64_decode($row['manifest']));
        }
        catch (Exception $e)
        {
            continue;
        }

        if (isset($installedManifest['manifest']) && isset($installedManifest['manifest']['acceptable_sugar_versions']) && isset($installedManifest['manifest']['acceptable_sugar_versions']['exact_matches']))
        {
            if (in_array($GLOBALS['sugar_version'], $installedManifest['manifest']['acceptable_sugar_versions']['exact_matches']))
            {
                if (isset($installedManifest['installdefs']) && isset($installedManifest['installdefs']['copy']))
                {
                    foreach ($installedManifest['installdefs']['copy'] as $copyFiles)
                    {
                        $name = $installedManifest['manifest']['name'];
                        $installedCopy[$name] = $copyFiles['to'];
                    }
                }
            }
        }
    }

    foreach($this->installdefs['copy'] as $newFiles)
    {
        if (in_array($newFiles['to'], $installedCopy))
        {
            $errors[] = "\"" . array_search($newFiles['to'], $installedCopy) . "\" conflicts with ./{$newFiles['to']}";
        }
    }
}

if (!empty($errors))
{
    foreach($errors as $error)
    {
        $GLOBALS['log']->fatal($error);
    }

    $this->abort($errors);
}