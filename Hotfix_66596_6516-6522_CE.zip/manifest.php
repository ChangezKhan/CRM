<?php

$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.16',
      1 => '6.5.17',
      2 => '6.5.18',
      3 => '6.5.19',
      4 => '6.5.20',
      5 => '6.5.21',
      6 => '6.5.22',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'readme' => '',
  'key' => 1441123243,
  'author' => 'SugarCRM',
  'description' => 'HotFix: Users relate field returns error in listview',
  'icon' => '',
  'is_uninstallable' => false,
  'name' => 'Bug 66596 6516-6522 (CE)',
  'published_date' => '2015-09-01 16:00:43',
  'type' => 'module',
  'version' => 1441123243,
  'remove_tables' => '',
);

$installdefs = array (
  'id' => 1441123243,
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/copy/include/ListView/ListViewDisplay.php',
      'to' => 'include/ListView/ListViewDisplay.php',
    ),
  ),
  'pre_execute' => 
  array (
    0 => '<basepath>/pre_execute/0.php',
  ),
);

?>